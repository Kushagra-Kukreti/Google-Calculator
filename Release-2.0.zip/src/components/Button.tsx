type valueProp = {
  total:()=>void
  value: string|number;
  setValue: React.Dispatch<React.SetStateAction<string>>;
};


const Button = ({value, setValue ,total}: valueProp) => {
  const handleValue = (value:string|number)=>{
   
        if(value === "AC")
        setValue("")
        else if(value === '='){
          total();
        }
        else{
          setValue(prev=>prev+value)
        }
     
  }

  if(value === "AC")

  return  <div
  onClick={() =>handleValue(value) }
  className="btn btn-danger m-2 w-100"
>
  {value}
</div>
 
else if(value === '=')


  return  <div
  onClick={() =>handleValue(value) }
  className="btn btn-primary m-2 w-100"
>
  {value}
</div>


 
else if((value<='3' || value =='4'|| value =='8') && value!='*' && value!='+'){
  return  <div 
  onClick={() =>handleValue(value) }
  className="btn btn-warning  m-2 w-100"
>
  {value}
</div>
}
 
  return <div 
  onClick={() => handleValue(value)} 
  className="btn btn-secondary m-2 w-100">
    {value}
    </div>
    
};

export default Button;
