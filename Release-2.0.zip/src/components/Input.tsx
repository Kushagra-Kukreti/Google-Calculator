



type currValueProp ={
  currValue:string
}
const Input = ({currValue}:currValueProp) => {

  return (
    
      <input 
      className="form-control" 
      value={currValue}
       
      style={
        { 
          textAlign:"end",
          width:"48%",
          marginLeft:"0.7rem"
        }
      }
      >

      </input>
    
  )
}

export default Input
