import Button from "./components/Button"
import Input from "./components/Input"
import { useState } from "react"





function App() {

   const buttonInfo:(string|number)[]= [0,1,2,3,4,5,6,7,8,9,'=','+','-','*',"AC"]

   const [currValue,setCurrValue] = useState("")

   const total =()=>{
      const ans = eval(currValue);
      setCurrValue(ans.toString());
   }
   return (
   <div
    className="container" 
    style={
      {
          display:"flex", 
          flexDirection:"column",
          alignItems:"center", 
          justifyContent:"center",
          gap:"0.5rem",
          marginTop:"8rem",
      }
          }>
   <h3 style={{color:"white"}}>Calculator App</h3>
   <Input currValue={currValue}/>
     <div className="row w-50">

      {buttonInfo.map((currButton)=>{
         return (<>
         {currButton === "AC"?
            <div className="col-6">
            <Button total={total} setValue ={setCurrValue} value={currButton}/>
            </div>:
            <div className="col-3">
            <Button total={total} setValue ={setCurrValue} value={currButton}/>
            </div>
         }
           

         </>)
      })}
      

     </div>
   
   </div>
   )
}

export default App
