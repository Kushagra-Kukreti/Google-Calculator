

const Input = () => {
  return (
    
      <input 
      type="text" 
      className="form-control" 
      style={
        {
          width:"48%",
          marginLeft:"0.7rem"
        }
      }
      >

      </input>
    
  )
}

export default Input
