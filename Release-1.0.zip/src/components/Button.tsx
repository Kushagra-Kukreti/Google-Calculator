


type valueProp ={
  value:string|number
}
const Button = ({value}:valueProp) => {
  return (
    <>
    { 
    value === '='||value === "AC"?<div className="btn btn-primary m-2 w-100">
      {value}
    </div>: <div className="btn btn-secondary m-2 w-100">
      {value}
    </div>}
   
    </>
  )
}

export default Button
